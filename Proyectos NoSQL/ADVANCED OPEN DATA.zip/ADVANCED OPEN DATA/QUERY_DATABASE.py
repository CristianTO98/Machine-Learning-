from pymongo import MongoClient
import certifi

# Connection to the Data Base
client = MongoClient(
    "mongodb+srv://CriTorOrt:CbT$-xEnj7zWpb6@cluster0.a7wziqk.mongodb.net/?retryWrites=true&w=majority",
    tlsCAFile=certifi.where())
db = client['Advance_Mongo_Open_Data']
collection = db['Calidad_Aire_Malaga_2018']

# QUERIES

# 1) Find all documents that intersect a specific polygon:

def query1():

    query = {
    'geometry': {
        '$geoIntersects': {
            '$geometry': {
                'type': 'Polygon',
                'coordinates': [
                    [
                        [
                            -4.449756334081712, 36.72423136243026
                        ], [
                            -4.451700176684341, 36.70736608196371
                        ], [
                            -4.436035092176411, 36.70314918336311
                        ], [
                            -4.425172442335651, 36.711491084962844
                        ], [
                            -4.449756334081712, 36.72423136243026
                        ]
                    ]
                ]
            }
        }
    }
    }

    documents = collection.find(query)
    count = 0
    for doc in documents:
        print(doc)
        count += 1
    print(f"Documentos encontrados = {count}")


# 2) Find all documents that are inside a circle with a given radius:
# Radio distance = 1 km
# Center = [ -4.4214415007679975, 36.72098492659043]

def query2():
    query = {
    'geometry': {
        '$geoWithin': {
            '$centerSphere': [[-4.4214415007679975, 36.72098492659043], 1 / 6738.4]
        }
    }
    }

    documents = collection.find(query)
    count = 0
    for doc in documents:
        print(doc)
        count += 1
    print(f"Documentos encontrados = {count}")


# 3) Find all documents that are within 500 m of a specific
# point and order them by distance from closest to farthest. Point = [-4.442394095598729,36.70541642565992]
# Note: to carry out this query, a 2dsphere spatial index must have been created on the "geometry" field
def query3():

    query = {
    'geometry': {
        '$nearSphere': {
            '$geometry': {
                'type': 'Point',
                'coordinates': [
                    -4.442394095598729, 36.70541642565992
                ]
            },
            '$minDistance': 0,
            '$maxDistance': 500
        }
    }
    }
    documents = collection.find(query)
    count = 0
    for doc in documents:
        print(doc)
        count += 1
    print(f"Documentos encontrados = {count}")

# 4) obtain the average of NO2, CO and O3 of air quality in a radius
# of 1000 meters around a specific point([-4.442394095598729, 36.70541642565992])

def query4():
    query = [
    {
        '$geoNear': {
            'near': {
                'type': 'Point',
                'coordinates': [
                    -4.442394095598729, 36.70541642565992
                ]
            },
            'distanceField': 'dist.calculated',
            'maxDistance': 1000,
            'query': {},
            'spherical': True
        }
    }, {
        '$group': {
            '_id': None,
            'Media_NO2': {
                '$avg': '$properties.no2'
            },
            'Media_CO': {
                '$avg': '$properties.co'
            },
            'Media_O3': {
                '$avg': '$properties.o3'
            }
        }
    }, {
        '$project': {
            '_id': 0
        }
    }
    ]

    documents = collection.aggregate(query)

    for doc in documents:
        print(doc)



# 5) Calculate the average ozone levels (o3) in all polygons
# that are within a circle of radius 10 km around the coordinates
# [-4.442394095598729, 36.70541642565992]

def query5():
    query = [
    {
        '$match': {
            'geometry': {
                '$geoWithin': {
                    '$centerSphere': [
                        [
                            -4.442394095598729, 36.70541642565992
                        ], 10 / 6738.4
                    ]
                }
            }
        }
    }, {
        '$group': {
            '_id': None,
            'Media_O3': {
                '$avg': '$properties.o3'
            }
        }
    }, {
        '$project': {
            '_id': 0
        }
    }
    ]

    documents = collection.aggregate(query)

    for doc in documents:
        print(doc)









