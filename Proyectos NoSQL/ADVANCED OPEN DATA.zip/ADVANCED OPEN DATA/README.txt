* El json a ser importado es el modificado. El json original es el descargado directamente desde el portal
de datos abiertos de Málaga, pero sin realizarle un tratamientos, es imposible importarlo a una base
de datos en Mongo. 

* En Indices.py se encuentra el indice que se ha creado necesario para las consultas espaciales con 
determinados operadores.

* En INSERT_DATASET.py están los comandos necesarios para insertar el dataset.

* En QUERY_DATABASE.py se encuentran las queries.