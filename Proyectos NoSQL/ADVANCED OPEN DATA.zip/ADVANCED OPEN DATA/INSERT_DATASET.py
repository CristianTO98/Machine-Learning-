from pymongo import MongoClient
import certifi
import json

# Connection to the Data Base
client = MongoClient("mongodb+srv://CriTorOrt:CbT$-xEnj7zWpb6@cluster0.a7wziqk.mongodb.net/?retryWrites=true&w=majority",
                     tlsCAFile = certifi.where())
db = client['Advance_Mongo_Open_Data']
collection = db['Calidad_Aire_Malaga_2018']

# Import Json to collection

with open('Original_2018_MODIFICADO.json','r') as f:
    documents = json.load(f)

collection.insert_many(documents)


# Checking inserts
query = collection.find()
count = 0
for q in query:
    print(q)
    count += 1

print(f'Nº documentos: {count} ')



