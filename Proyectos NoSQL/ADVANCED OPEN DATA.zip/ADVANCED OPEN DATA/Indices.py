import pymongo
from pymongo import MongoClient
import certifi
import json

# Connection to the Data Base
client = MongoClient("mongodb+srv://CriTorOrt:CbT$-xEnj7zWpb6@cluster0.a7wziqk.mongodb.net/?retryWrites=true&w=majority",
                     tlsCAFile = certifi.where())
db = client['Advance_Mongo_Open_Data']
collection = db['Calidad_Aire_Malaga_2018']

collection.create_index([("geometry", pymongo.GEOSPHERE)])

