un = "UBD3722"
pw = "Xbox36098"
host = "afrodita.lcc.uma.es"
sid = "APOLO"