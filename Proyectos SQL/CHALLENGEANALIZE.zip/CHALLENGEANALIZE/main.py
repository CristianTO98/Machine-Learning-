import oracledb
import pandas as pd
import config

connection = oracledb.connect(user=config.un, password=config.pw, host=config.host, sid=config.sid)
cursor = connection.cursor()


query1 = """
SELECT COUNT(ID) FROM UBD3707.AUDIT_TABLE"""
comandosTotales = cursor.execute(query1).fetchall()[0][0]
print(f"\nLos número de comandos DML totales son: {comandosTotales}\n")

query2 = """SELECT TIPO, TABLA, COUNT(*) FROM UBD3707.AUDIT_TABLE
WHERE TIPO = 'INSERT'
GROUP BY TIPO, TABLA"""

print("La cantidad de inserts por tablas son: \n")

rows = cursor.execute(query2)
for row in rows:
    print(f"\t{row[1]} -----> {row[2]}")

print("")

query3 = """SELECT TIPO, TABLA, COUNT(*) FROM UBD3707.AUDIT_TABLE
WHERE TIPO = 'DELETE'
GROUP BY TIPO, TABLA"""

print("La cantidad de deletes por tablas son: \n")

rows = cursor.execute(query2)
for row in rows:
    print(f"\t{row[1]} -----> {row[2]}")

print("")

query3 = """SELECT TIPO, TABLA, COUNT(*) FROM UBD3707.AUDIT_TABLE
WHERE TIPO = 'UPDATE'
GROUP BY TIPO, TABLA"""

print("La cantidad de updates por tablas son: \n")

rows = cursor.execute(query2)
for row in rows:
    print(f"\t{row[1]} -----> {row[2]}")

print("")

query3 = """SELECT USUARIO, COUNT(*) FROM UBD3707.AUDIT_TABLE
GROUP BY USUARIO"""

print("Cantidad comandos DML por ususario: \n")

rows = cursor.execute(query3)
for row in rows:
    print(f"\t{row[0]} -----> {row[1]}")

print("")


print("% comandos DML por ususario: \n")

rows = cursor.execute(query3)
for row in rows:
    print(f"\t{row[0]} -----> {(row[1]/comandosTotales)*100}")





connection.commit()

cursor.close()

connection.close()