import subprocess
import time
import uuid

import docker
import redis
from structlog import get_logger
from logger import init_logger

init_logger()

log = get_logger("autoscale")

r = redis.Redis()

# Check if connection to Redis is successful.
try:
    r.ping()
except redis.exceptions.ConnectionError:
    log.error("Cannot connect to Redis")
    exit(1)

log.info("Connected to Redis")

workers = set()
client = docker.from_env()

log.info("Starting reconciliation loop")

# Reconciliation loop to ensure we have the right number of workers.
while True:
    # Get length of list 'default'.
    pending_tasks = r.llen("default")

    log.info("Scheduling pending tasks", pending_tasks=pending_tasks, workers=len(workers))

    # If there are more than 50 pending tasks, scale up to 5 workers.
    if pending_tasks > 50:
        desired = 5
    # Scale up to 3 workers if pending tasks is between 5 and 50.
    elif 5 < pending_tasks <= 50:
        desired = 3
    # Scale down to 1 worker if pending tasks is less than 5.
    elif 0 < pending_tasks <= 5:
        desired = 1
    else:
        desired = 0

    # Compare desired number of workers with current number of workers
    # and start or stop workers as needed.
    if desired != len(workers):
        log.info("Auto-scaling", pending_tasks=pending_tasks, desired=desired, workers=len(workers))
        if desired > len(workers):
            for i in range(desired - len(workers)):
                log.info("Starting new worker")
                cid = f"worker--{uuid.uuid4().hex}"
                #p = subprocess.Popen(["docker", "worker.py"], stdout=subprocess.DEVNULL)
                client.containers.run("scaler:1.0.0",
                                      detach = True,
                                      enviroment={
                                          "REDIS_HOST": "redis",
                                          "REDIS_PORT": "6379",
                                          "LOGTAIL_KEY": "",
                                      })
                workers.add(cid)
        else:
            for i in range(len(workers) - desired):
                cid = workers.pop()
                try:
                    client.containers.get(cid).stop()
                except Exception:
                    pass

    else:
        time.sleep(1.0)  # Reconcile interval.
