package org.uma.mbd.mdRectas.rectas;

public class Punto {

    // Atributos de la clase
    private double x,y;

    // Método constructor
    public Punto(double a, double b){
        x = a;
        y = b;
    }

    public Punto(){
        x = 0;
        y = 0;
    }

    // Métodos de la clase Punto

    public double distancia(Punto punto){

        double distancia;
        distancia = Math.sqrt(Math.pow(punto.x-x,2) + Math.pow(punto.y-y,2));
        return distancia;

    }

    public void trasladar(double x2, double y2){

        x += x2;
        y += y2;

    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    @Override
    public String toString(){

        return "P(x= "+x+", y= "+y+")";

    }

}
