package org.uma.mbd.mdRectas.rectas;

record Implicita(double a, double b, double c) {}
