package org.uma.mbd.mdRectas.rectas;

public class Vector {

    // Atributos(solo 1 punto) ya que suponemos que sale de origen

    private Punto extremo;


    //Métodos constructores

    public Vector(Punto p){

        extremo = p;

    }


    public Vector(Punto p1, Punto p2){

        extremo = new Punto(p2.getX()-p1.getX(),p2.getY()-p1.getY());

    }


    public Vector(double a, double b){


        extremo = new Punto(a,b);


    }

    // Métodos

    public Vector ortogonal(){
        return new Vector(-extremo.getY(), extremo.getX());
    }

    public boolean paraleloA(Vector v){
        if (extremo.getX()*v.extremo.getY() == extremo.getY()*v.extremo.getX()){
            return true;
        }

        else{
            return false;
        }

        }


    public Punto extremoDesde(Punto org) {

        Punto nuevoExtremo = new Punto(extremo.getX(), extremo.getY());

        nuevoExtremo.trasladar(org.getX(), org.getY());

        return nuevoExtremo;

    }


    public double modulo(){

        double modulo;
        modulo = Math.sqrt((Math.pow(extremo.getX(),2) + Math.pow(extremo.getY(),2)));
        return modulo;

    }


    public double getComponenteX(){
        return extremo.getX();
    }

    public double getComponenteY(){
        return extremo.getY();
    }


    @Override
    public String toString(){
        return "V("+extremo.getX()+", "+extremo.getY()+")";
    }



}










