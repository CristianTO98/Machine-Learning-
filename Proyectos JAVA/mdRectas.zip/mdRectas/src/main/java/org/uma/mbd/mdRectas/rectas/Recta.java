package org.uma.mbd.mdRectas.rectas;


public class Recta {

    // Atributos
    private Vector direccion;
    private Punto pto;

    // Métodos constructores

    public Recta(Vector v, Punto p){

        direccion = new Vector(v.getComponenteX(),v.getComponenteY());
        pto = new Punto(p.getX(),p.getY());

    }

    public Recta(Punto orig, Punto extre){

        direccion = new Vector(extre.getX() - orig.getX(), extre.getY() - orig.getY());
        pto = new Punto(extre.getX(), extre.getY());


    }

    // Métodos

    public boolean paralelaA(Recta r){

        return direccion.paraleloA(r.direccion);

    }

    public boolean pasaPor(Punto p){

        Vector vector_p_pto = new Vector(pto.getX()-p.getX(), pto.getY()-p.getY());

        return vector_p_pto.paraleloA(direccion);

    }

    private Implicita implicita(){
        double a,b,c;
        a = direccion.getComponenteY();
        b = - direccion.getComponenteX();
        c = -pto.getX()*direccion.getComponenteY() + direccion.getComponenteX()*pto.getY();
        return new Implicita(a,b,c);
    }

    private static double determinante(double a11, double a12, double a21, double a22){

        double resultado;
        resultado = a11*a22 - a12*a21;

        return resultado;

    }

    public Punto interseccionCon(Recta r){

        double x,y, numx, denomx, numy, denomy;
        Implicita r1, r2;

        // Ecuaciones implicitas
        r1 = implicita();
        r2 = r.implicita();


        // Coordenadas punto de corte

        numx = determinante(-r1.c(), r1.b(), -r2.c(), r2.b());
        denomx = determinante(r1.a(), r1.b(), r2.a(), r2.b());
        numy = determinante(r1.a(), -r1.c(), r2.a(), -r2.c());
        denomy = determinante(r1.a(), r1.b(), r2.a(), r2.b());

        if(denomx == 0 || denomy == 0)
            throw new ArithmeticException();



        x = numx / denomx;
        y = numy / denomy;


        return new Punto(x,y);

    }

    public Recta paralelaPor(Punto p){

        return new Recta(direccion, p);

    }

    public Recta perpendicularPor(Punto p){

        Vector ortogonal = direccion.ortogonal();
        return new Recta(ortogonal, p);

    }

    public double distanciaDesde(Punto p){
        //Recta ortogonal a la actual que pase por p
        Vector perpendicular = direccion.ortogonal();

        Recta ortogonal = new Recta(perpendicular,p);

        // Punto intersección de ambas rectas

        Punto corte = interseccionCon(ortogonal);

        // Devolvemos la distancia
        return corte.distancia(p);


    }

    @Override
    public String toString(){

        return "R(V("+ direccion.getComponenteX()+", "+ direccion.getComponenteY()+")," +
                " P("+pto.getX()+", "+ pto.getY()+"))";

    }



}
