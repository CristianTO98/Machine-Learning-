package org.uma.mbd.mdBusV2.buses;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class Servicio {

    private String ciudad;
    private SortedSet<Bus> buses;

    public Servicio(String nombreCiudad) {
        ciudad = nombreCiudad;
        buses = new TreeSet<>();

    }

    public String getCiudad() {
        return ciudad;
    }

    public Set<Bus> getBuses() {
        return buses;
    }

    public void leeBuses(String file) throws IOException {

        try (BufferedReader br = Files.newBufferedReader(Path.of(file))) {
            String linea = br.readLine();
            while (linea != null) {
                try (Scanner scLinea = new Scanner(linea)) {
                    scLinea.useDelimiter(",");
                    int codbus = scLinea.nextInt();
                    String matricula = scLinea.next();
                    int codLinea = scLinea.nextInt();
                    buses.add(new Bus(codbus, matricula));
                    for (Bus b : buses) {
                        if (b.equals(new Bus(codbus, matricula)))
                            b.setCodLinea(codLinea);
                    }

                } catch (InputMismatchException e) {
                    System.out.println("Error en dato numérico en " + linea);


                } catch (NoSuchElementException e) {
                    System.out.println("Error, faltan datos en " + linea);


                } finally {
                    linea = br.readLine();
                }

            }

        }

    }

    public SortedSet<Bus> filtra(Criterio criterio, Comparator<Bus> cb) {
        SortedSet<Bus> busesSelec = new TreeSet<>(cb);

        for (Bus b : buses) {
            if (criterio.esSeleccionable(b))
                busesSelec.add(b);
        }
        return busesSelec;
    }


    public void guarda(String file, Criterio criterio, Comparator<Bus> cb) throws FileNotFoundException {
        try (PrintWriter pw = new PrintWriter(file)) {
            guarda(pw, criterio, cb);
        }
    }

    public void guarda(PrintWriter pw, Criterio criterio, Comparator<Bus> cb) {
        pw.println(criterio);
        for (Bus bus : filtra(criterio, cb)) {
            pw.println(bus);
        }

    }


}
