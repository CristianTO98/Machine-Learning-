package org.uma.mbd.mdUrna.urna;

import java.util.NoSuchElementException;
import java.util.Random;

public class Urna {

// Atributos de clase
    public static enum ColorBola {Blanca, Negra};
    private static Random alea = new Random();



// Atributos de instancia

    private int blancas, negras;


// Método constructor

    public Urna(int b, int n){

        if (b <= 0 || n <= 0)
            throw new IllegalArgumentException();

        blancas = b;
        negras = n;
    }

// Métodos
    public int totalBolas(){
        return blancas + negras;
    }

    public ColorBola extraerBola(){

        if (totalBolas() == 0)
            throw new NoSuchElementException();

        int numBolaExt = 1 + alea.nextInt(totalBolas());

        if (numBolaExt <= blancas) {
            blancas--;
            return ColorBola.Blanca;
        }

        else {
            negras--;
            return ColorBola.Negra;
        }


    }

    public void ponerBlanca(){
        blancas++;
    }

    public void ponerNegra(){
        negras++;
    }

    @Override
    public String toString(){
        return "U(B: " + blancas + "N: " + negras + ")";
    }












}
