package org.uma.mbd.mdUrna;

import org.uma.mbd.mdUrna.urna.Urna;

/* CASOS DE ESTUDIO

+ Blancas Pares y negras Impares ------> Negra (Resultado no cambia al introducir más cantidad de un color que de otro)

+ Blancas Impares y Negras Impares ----> Negra (Resultado no cambia al introducir más cantidad de un color que de otro
                                                  o misma cantidad)

+ Blancas Impares y negras Pares ------> Blanca (Resultado no cambia al introducir más cantidad de un color que de otro)

+ Blancas Pares y negras Pares --------> Blanca (Resultado no cambia al introducir más cantidad de un color que de otro
                                                  o misma cantidad)
 */

public class Main {

    public static void main(String[] args) {

        Urna u = new Urna(Integer.parseInt(args[0]), Integer.parseInt(args[1]));

        do{

            Urna.ColorBola b1 = u.extraerBola();
            Urna.ColorBola b2 = u.extraerBola();

            if ((b1 == Urna.ColorBola.Blanca && b2 == Urna.ColorBola.Blanca) || (b1 == Urna.ColorBola.Negra && b2 == Urna.ColorBola.Negra)) {

                u.ponerBlanca();
            }

            else {
                u.ponerNegra();
            }



        }while (u.totalBolas() > 1);

        // Ya solo queda 1 bola

        System.out.println(u.extraerBola());







    }

}
