package org.uma.mbd.mdBusV1L.buses;

public class EnMatricula implements Criterio {

    private String dato;

    public EnMatricula(String d) {
        dato = d;
    }

    @Override
    public boolean esSeleccionable(Bus b) {
        return b.getMatricula().contains(dato);
    }

    @Override
    public String toString() {
        return "Autobuses cuya matrícula contiene " + dato;
    }


}
