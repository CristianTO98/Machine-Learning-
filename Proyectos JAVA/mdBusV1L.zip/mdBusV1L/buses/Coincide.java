package org.uma.mbd.mdBusV1L.buses;

public class Coincide implements Criterio {

    private Bus bus;

    public Coincide(Bus b) {
        bus = b;
    }


    @Override
    public boolean esSeleccionable(Bus b) {
        return b.equals(bus);
    }

    @Override
    public String toString() {
        return "Autobús" + bus;
    }
}
