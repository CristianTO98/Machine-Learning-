package org.uma.mbd.mdBusV1L.buses;


public class Bus {

    private int codBus;
    private int codLinea;
    private String matricula;

    public Bus(int codBus, String matricula) {
        this.codBus = codBus;
        this.matricula = matricula;
        codLinea = 0;
    }

    public void setCodLinea(int codLinea) {
        this.codLinea = codLinea;
    }

    public int getCodBus() {
        return codBus;
    }

    public int getCodLinea() {
        return codLinea;
    }

    public String getMatricula() {
        return matricula;
    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof Bus b) && codBus == b.codBus && matricula.equalsIgnoreCase(b.matricula);
    }

    @Override
    public int hashCode() {
        return matricula.toLowerCase().hashCode() + Integer.hashCode(codBus);
    }

    @Override
    public String toString() {
        return "Bus(" + codBus + ", " + matricula + ", " + codLinea + ")";
    }


}
