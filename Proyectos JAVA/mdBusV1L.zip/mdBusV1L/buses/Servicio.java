package org.uma.mbd.mdBusV1L.buses;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class Servicio {

    private String ciudad;
    private List<Bus> buses;

    public Servicio(String nombreCiudad) {
        ciudad = nombreCiudad;
        buses = new ArrayList<>();
    }

    public String getCiudad() {
        return ciudad;
    }

    public List<Bus> getBuses() {
        return buses;
    }

    public void leeBuses(String file) throws IOException {

        try (BufferedReader br = Files.newBufferedReader(Path.of(file))) {
            String linea = br.readLine();
            while (linea != null) {
                try (Scanner scLinea = new Scanner(linea)) {
                    scLinea.useDelimiter(",");
                    int codbus = scLinea.nextInt();
                    String matricula = scLinea.next();
                    int codLinea = scLinea.nextInt();
                    buses.add(new Bus(codbus, matricula));
                    buses.get(buses.size() - 1).setCodLinea(codLinea);

                } catch (InputMismatchException e) {
                    System.out.println("Error en dato numérico en " + linea);


                } catch (NoSuchElementException e) {
                    System.out.println("Error, faltan datos en " + linea);


                } finally {
                    linea = br.readLine();
                }

            }

        }

    }

    public List<Bus> filtra(Criterio criterio) {
        List<Bus> busesSelec = new ArrayList<>();

        for (Bus b : buses) {
            if (criterio.esSeleccionable(b))
                busesSelec.add(b);
        }
        return busesSelec;
    }


    public void guarda(String file, Criterio criterio) throws FileNotFoundException {
        try(PrintWriter pw = new PrintWriter(file)) {
            guarda(pw, criterio);
        }
    }

    public void guarda(PrintWriter pw, Criterio criterio) {
        pw.println(criterio);
        for (Bus bus : filtra(criterio)) {
            pw.println(bus);
        }

    }


}
