package org.uma.mbd.mdBusV1L;

import org.uma.mbd.mdBusV1L.buses.Bus;
import org.uma.mbd.mdBusV1L.buses.Servicio;

import java.io.IOException;

public class MainPrueba  {

    public static void main(String[] args) throws IOException {

        String file = "recursos/mdBusV1/buses.txt";
        Servicio servicio = new Servicio("Malaga");
        servicio.leeBuses(file);
        System.out.println("La ciudad del servicio es " + servicio.getCiudad());
        System.out.println("Los buses disponibles son: ");
        for(Bus b: servicio.getBuses()){
            System.out.println(b);
        }




    }

}
