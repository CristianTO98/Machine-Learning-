package org.uma.mbd.mdNPI;
import org.uma.mbd.mdNPI.npi.NPI;


public class Main {



    public static void main(String[] args) {


        // Declaramos el objeto de la clase NPI bajo el nombre de calculadora

        NPI calculadora = new NPI();

        // Introducimos las ordenes necearias para calcular la expresión en NPI, ponemos toString para ver el proceso de cálculo.
        calculadora.entra(3);
        System.out.println(calculadora.toString());
        calculadora.entra(6);
        System.out.println(calculadora.toString());
        calculadora.entra(2);
        System.out.println(calculadora.toString());
        calculadora.resta();
        System.out.println(calculadora.toString());
        calculadora.multiplica();
        System.out.println(calculadora.toString());
        calculadora.entra(5);
        System.out.println(calculadora.toString());
        calculadora.suma();
        System.out.println(calculadora.toString());

        //  Imprimimos el resultado
        System.out.println("\nEl resultado es "+calculadora.getResultado());


    }
}
