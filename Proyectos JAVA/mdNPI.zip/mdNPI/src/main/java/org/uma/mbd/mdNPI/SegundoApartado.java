package org.uma.mbd.mdNPI;


import org.uma.mbd.mdNPI.npi.NPI;

public class SegundoApartado {


    public static void main(String[] args) {

        // Declaramos el objeto
        NPI calculadora = new NPI();

        // Introducimos la expresión a calcular en notación polaca inversa
        // Empleampos toString para observar el proceso de calculo
        calculadora.entra(3);
        System.out.println(calculadora.toString());
        calculadora.entra(6);
        System.out.println(calculadora.toString());
        calculadora.entra(2);
        System.out.println(calculadora.toString());
        calculadora.resta();
        System.out.println(calculadora.toString());
        calculadora.multiplica();
        System.out.println(calculadora.toString());
        calculadora.entra(2);
        System.out.println(calculadora.toString());
        calculadora.entra(7);
        System.out.println(calculadora.toString());
        calculadora.suma();
        System.out.println(calculadora.toString());
        calculadora.entra(5);
        System.out.println(calculadora.toString());
        calculadora.divide();
        System.out.println(calculadora.toString());
        calculadora.suma();
        System.out.println(calculadora.toString());

        // Mostramos el resultado

        System.out.println("El resultado es "+calculadora.getResultado());







    }









}
