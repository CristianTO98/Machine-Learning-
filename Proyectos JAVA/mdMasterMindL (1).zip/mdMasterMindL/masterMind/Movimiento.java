package org.uma.mbd.mdMasterMindL.masterMind;

public record Movimiento(String intento, int colocadas, int descolocadas) {
}
