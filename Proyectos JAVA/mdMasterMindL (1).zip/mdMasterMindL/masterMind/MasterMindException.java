package org.uma.mbd.mdMasterMindL.masterMind;

public class MasterMindException extends RuntimeException {

    public MasterMindException() {
        super();
    }

    public MasterMindException(String m) {
        super(m);
    }


}
