package org.uma.mbd.mdMasterMindL.masterMind;

import java.util.Random;


public class MasterMind {

    public static final int TAMANO_POR_DEFECTO = 4;
    private static Random alea = new Random();
    protected String combinacionSecreta = "";

    public MasterMind(int tamano) {
        if (tamano <= 0 || tamano > 10)
            throw new MasterMindException("No puede introducir un argumento no positivo, 0 o mayor que el número de cifras disponibles (10)");
        generaGeneraCombinacionSecreta(tamano);
    }

    public MasterMind() {
        this(TAMANO_POR_DEFECTO);
    }

    public MasterMind(String combinacionSecreta) {
        this.combinacionSecreta = combinacionSecreta;
    }

    private void generaGeneraCombinacionSecreta(int tamano) {

        while (combinacionSecreta.length() < tamano) {
            int numAl = alea.nextInt(0, 10);
            if (combinacionSecreta.indexOf(Integer.toString(numAl)) < 0) {
                combinacionSecreta += numAl;
            }
        }
    }

    public int getLongitud() {
        return combinacionSecreta.length();
    }

    private boolean validaCombinacion(String cifras) {
        boolean check = true;
        if (!cifras.matches("\\d{" + combinacionSecreta.length() + "}"))
            check = false;

        for (int i = 0; check && i < cifras.length(); i++) {
            if (cifras.lastIndexOf(cifras.charAt(i)) != i) {
                check = false;

            }

        }

        return check;
    }

    public Movimiento intento(String cifras) {
        if (!validaCombinacion(cifras))
            throw new MasterMindException("""
                    La combinación no es válida, los motivos pueden ser:
                    * La combinación secreta sea de mayor longitud que la requerida.
                    * Todos los caracteres no son numéricos.
                    * Contiene cifras repetidas.""");

        int numCifrasMismaPos = 0, numCifrasDifPos = 0;

        for (int i = 0; i < cifras.length(); i++) {
            int n = combinacionSecreta.indexOf(cifras.charAt(i));
            if (n == i) {
                numCifrasMismaPos++;
            } else if (n >= 0) {
                numCifrasDifPos++;
            }
        }
        return new Movimiento(cifras, numCifrasMismaPos, numCifrasDifPos);


    }


    public String getSecreto() {
        return combinacionSecreta;
    }


}