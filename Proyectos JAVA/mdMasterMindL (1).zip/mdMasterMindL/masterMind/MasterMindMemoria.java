package org.uma.mbd.mdMasterMindL.masterMind;

import java.util.ArrayList;
import java.util.List;

public class MasterMindMemoria extends MasterMind {

    private List<Movimiento> movimientos;

    public MasterMindMemoria(int tamano) {
        super(tamano);
        movimientos = new ArrayList<>();
    }

    public MasterMindMemoria() {
        this(TAMANO_POR_DEFECTO);
    }

    public MasterMindMemoria(String combinacionSecreta) {
        super(combinacionSecreta);
        movimientos = new ArrayList<>();
    }


    @Override
    public Movimiento intento(String cifras) {
        Movimiento mov = super.intento(cifras);
        if (movimientos.contains(mov))
            throw new MasterMindException("Ha introducido un intento ya probado anteriormente");

        movimientos.add(mov);
        return mov;

    }


    public List<Movimiento> movimientos() {
        return movimientos;
    }


}
