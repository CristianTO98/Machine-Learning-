package org.uma.mbd.mdAlturas.alturas;

@FunctionalInterface
public interface Seleccion {

    boolean test(Pais pais);

}
