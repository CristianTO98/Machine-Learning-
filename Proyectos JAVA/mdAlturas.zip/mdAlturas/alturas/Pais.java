package org.uma.mbd.mdAlturas.alturas;

public record Pais(String nombre, String continente, double altura) {
}
