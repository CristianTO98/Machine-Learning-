package org.uma.mbd.mdCoche.coches;

public class Coche {

    // Variable de clase
    private static double PIVA = 0.16;

    // Variables de instancias
    private String nombre;
    private double precio;

    // Método cosntructor
    public Coche(String n, double p) {

        nombre = n;
        precio = p;

    }

    //Métodos


    public static void setPiva(double PIVA) {
        Coche.PIVA = PIVA;
    }


    public double precioTotal() {

        return precio + precio * PIVA;

    }

    @Override
    public String toString() {
        return nombre + " -------> " + precioTotal();
    }


}
