package org.uma.mbd.mdCoche.coches;

public class CocheImportado extends Coche {

    // Atributos clase
    private double homologacion;

    // Método constructor

    public CocheImportado(String n, double p, double h) {
        super(n, p);
        homologacion = h;
    }

    @Override
    public double precioTotal() {

        return super.precioTotal() + homologacion;
    }


}
