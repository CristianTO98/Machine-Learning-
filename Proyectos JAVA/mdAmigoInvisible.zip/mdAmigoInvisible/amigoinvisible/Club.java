package org.uma.mbd.mdAmigoInvisible.amigoinvisible;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class Club {

    protected List<Persona> socios;


    public Club() {
        socios = new ArrayList<>();
    }


    public void lee(String fEntrada, String delim) throws IOException {
        try (BufferedReader br = Files.newBufferedReader(Path.of(fEntrada))) {

            String linea = br.readLine();
            while (linea != null) {
                leeSocios(linea, delim);
                linea = br.readLine();
            }
        }
    }

    private void leeSocios(String linea, String delim) {

        try (Scanner scPersona = new Scanner(linea)) {
            scPersona.useDelimiter(delim);
            while (scPersona.hasNext()) {
                creaSocioDesdeString(scPersona.next());
            }
        }
    }

    protected void creaSocioDesdeString(String nombre) {
        socios.add(new Persona(nombre));
    }

    protected void hacerAmigos() {

        List<Integer> posAmigos = new ArrayList<>();
        // Rellenamos la lista
        for (int i = 0; i < socios.size(); i++) {
            posAmigos.add(i);
        }
        // Verificamos coincidencias
        while (hayCoincidencias(posAmigos)) {
            Collections.shuffle(posAmigos);
        }

        // Hacemos emparejamiento

        for (int i = 0; i < posAmigos.size(); i++) {
            socios.get(i).setAmigo(socios.get(posAmigos.get(i)));
        }

    }

    private static boolean hayCoincidencias(List<Integer> list) {

        boolean check = false;
        for (int i = 0; i < list.size() && !check; i++) {
            if (i == list.get(i))
                check = true;
        }
        return check;


    }

    public void presentaAmigos(String fSalida) throws FileNotFoundException {

        try (PrintWriter pwfSalida = new PrintWriter(fSalida)) {
            presentaAmigos(pwfSalida);
        }

    }

    public void presentaAmigos(PrintWriter pw) {
        Collections.sort(socios);
        pw.println("Los amigos invisibles generados son: ");
        for (Persona p : socios) {
            pw.println(p);
        }

    }


}
