package org.uma.mbd.mdAmigoInvisible.amigoinvisible;

import java.util.*;

public class ClubParejas extends Club {

    private Set<Pareja> parejas;

    public ClubParejas() {
        super();
        parejas = new HashSet<>();
    }

    @Override
    protected void creaSocioDesdeString(String nombre) {
        if (nombre.contains("-")) { //Se trata de una pareja
            try (Scanner scPareja = new Scanner(nombre)) {
                scPareja.useDelimiter("-");
                String p1 = scPareja.next();
                String p2 = scPareja.next();
                parejas.add(new Pareja(new Persona(p1), new Persona(p2)));
                socios.add(new Persona(p1));
                socios.add(new Persona(p2));
            }
        } else {
            socios.add(new Persona(nombre));
        }
    }

    @Override
    protected void hacerAmigos() {
        boolean checkParejas;
        do {
            super.hacerAmigos();
            checkParejas = false;
            int contador = 0;
            while (contador < socios.size() && !checkParejas) {
                if (parejas.contains(new Pareja(socios.get(contador), socios.get(contador).getAmigo())))
                    checkParejas = true;
                contador++;
            }

        } while (checkParejas);


    }


}
