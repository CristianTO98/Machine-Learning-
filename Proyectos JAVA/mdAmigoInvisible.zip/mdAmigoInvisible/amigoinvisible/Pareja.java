package org.uma.mbd.mdAmigoInvisible.amigoinvisible;

public record Pareja(Persona uno, Persona otro) {

    @Override
    public boolean equals(Object o) {
        return (o instanceof Pareja p) &&
                (uno.getNombre().equalsIgnoreCase(p.uno.getNombre()) || uno.getNombre().equalsIgnoreCase(p.otro.getNombre()))
                && (otro.getNombre().equalsIgnoreCase(p.uno.getNombre()) || otro.getNombre().equalsIgnoreCase(p.otro.getNombre()));
    }

    @Override
    public int hashCode() {
        return uno.getNombre().hashCode() + otro.getNombre().hashCode();
    }

}

