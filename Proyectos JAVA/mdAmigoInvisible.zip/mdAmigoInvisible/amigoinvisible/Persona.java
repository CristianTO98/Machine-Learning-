package org.uma.mbd.mdAmigoInvisible.amigoinvisible;

public class Persona implements Comparable<Persona> {

    private String nombre;
    private Persona amigo;

    public Persona(String n) {
        nombre = n;
    }


    public String getNombre() {
        return nombre;
    }

    public Persona getAmigo() {
        return amigo;
    }

    public void setAmigo(Persona am) {
        this.amigo = am;
    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof Persona p) && nombre.equalsIgnoreCase(p.nombre);
    }

    @Override
    public int hashCode() {
        return nombre.toLowerCase().hashCode();
    }


    @Override
    public String toString() {
        if (amigo != null)
            return amigo.nombre + " --> " + nombre;
        else
            return nombre + " --> sin amigo";
    }


    @Override
    public int compareTo(Persona o) {
        return nombre.compareToIgnoreCase(o.nombre);
    }
}
