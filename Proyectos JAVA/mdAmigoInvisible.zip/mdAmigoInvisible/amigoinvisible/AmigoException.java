package org.uma.mbd.mdAmigoInvisible.amigoinvisible;

public class AmigoException extends RuntimeException {

    public AmigoException() {
        super();
    }

    public AmigoException(String msg) {
        super(msg);
    }


}
