package org.uma.mbd.mdAmigoInvisible.amigoinvisible;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;

public class ClubManager {

    private String fEntrada;
    private String delimitadores;
    private String fSalida;
    private boolean consola;
    private Club club;


    public ClubManager(Club club) {
        this.club = club;
    }

    public ClubManager setEntrada(String entrada, String delim) {

        fEntrada = entrada;
        delimitadores = delim;
        return this;

    }


    public ClubManager setSalida(String salida) {

        fSalida = salida;
        return this;
    }

    public ClubManager setConsola(boolean consola) {
        this.consola = consola;
        return this;
    }

    private void verify() throws IOException {
        // Existe entrada
        if (fEntrada == null)
            throw new AmigoException("La variable de entrada de datos está vacía, " +
                    "por lo que no se tiene directorio disponible");

        if (!Files.exists(Path.of(fEntrada))) {
            throw new AmigoException("No existe fichero de entrada de datos");
        } else {
            try (BufferedReader br = Files.newBufferedReader(Path.of(fEntrada))) {
                if (br.readLine() == null)
                    throw new AmigoException("El fichero de entrada existe, pero está vacío.");
            }
        }

        // Existe salida
        if (fSalida == null && !consola)
            throw new AmigoException("No hay salida. Ni a fichero, ni a consola.");

    }

    public void build() throws IOException {
        verify();
        club.lee(fEntrada, delimitadores);
        club.hacerAmigos();
        if (consola) {
            club.presentaAmigos(fSalida);
            club.presentaAmigos(new PrintWriter(System.out, true));
        } else
            club.presentaAmigos(fSalida);

    }


}
