package org.uma.mbd.mdIndicePalabrasv1.indices;

import java.util.*;

public class Indice1aLinea extends Indice {

    private Map<String, Integer> indice;

    public Indice1aLinea() {
        super();
        indice = new TreeMap<>();
    }

    @Override
    public void agregarLinea(String texto) {
        super.agregarLinea(texto);
        indice.clear();


    }

    @Override
    public void resolver(String delimitadores, Collection<String> noSignificativas) {

        // Introducimos en un conjunto las palabras no significativas en minúsculas.
        Set<String> conjNoSignif = super.crearSetNoSignMinuscula(noSignificativas);

        //Analizamos el texto para formar el indice

        for (int i = 0; i < texto.size(); i++) {
            try (Scanner scLineaText = new Scanner(texto.get(i))) {
                scLineaText.useDelimiter(delimitadores);
                while (scLineaText.hasNext()) {
                    String palabra = scLineaText.next().toLowerCase();
                    if (!conjNoSignif.contains(palabra)) {
                        //Buscamos palabra en el diccionario
                        int linea = i + 1;
                        indice.computeIfAbsent(palabra, key -> linea);
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println(e.getMessage());
            } catch (NoSuchElementException e) {
                System.out.println(e.getMessage());
            }

        }


    }

    @Override
    public void presentarIndiceConsola() {

        for (Map.Entry<String, Integer> entrada : indice.entrySet()) {
            String clave = entrada.getKey();
            int valor = entrada.getValue();
            System.out.println(clave + "\t\t" + valor);
        }

    }


}
