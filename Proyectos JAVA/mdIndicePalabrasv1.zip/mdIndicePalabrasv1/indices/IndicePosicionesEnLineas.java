package org.uma.mbd.mdIndicePalabrasv1.indices;

import java.util.*;

public class IndicePosicionesEnLineas extends Indice {

    private Map<String, Map<Integer, Set<Integer>>> indice;

    public IndicePosicionesEnLineas() {
        super();
        indice = new TreeMap<>();
    }


    @Override
    public void agregarLinea(String texto) {
        super.agregarLinea(texto);
        indice.clear();

    }

    @Override
    public void resolver(String delimitadores, Collection<String> noSignificativas) {

        // Introducimos en un conjunto las palabras no significativas en minúsculas.
        Set<String> conjNoSignif = super.crearSetNoSignMinuscula(noSignificativas);

        //Analizamos el texto para formar el indice

        for (int i = 0; i < texto.size(); i++) {
            try (Scanner scLineaText = new Scanner(texto.get(i))) {
                scLineaText.useDelimiter(delimitadores);
                int counter = 0;
                while (scLineaText.hasNext()) {
                    String palabra = scLineaText.next().toLowerCase();
                    counter++;
                    if (!conjNoSignif.contains(palabra)) {
                        //Buscamos palabra en el diccionario
                        Map<Integer, Set<Integer>> valor = indice.computeIfAbsent(palabra, key -> new TreeMap<>());
                        Set<Integer> valor2 = valor.computeIfAbsent(i + 1, key -> new TreeSet<>());
                        valor2.add(counter);
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println(e.getMessage());
            } catch (NoSuchElementException e) {
                System.out.println(e.getMessage());
            }

        }


    }

    @Override
    public void presentarIndiceConsola() {

        for (Map.Entry<String, Map<Integer, Set<Integer>>> entrada : indice.entrySet()) {
            String palabra = entrada.getKey();
            System.out.println(palabra);
            for (Map.Entry<Integer, Set<Integer>> entrada2 : entrada.getValue().entrySet()) {
                String salidaPos = "";
                Integer linea = entrada2.getKey();
                Set<Integer> palabraPos = entrada2.getValue();
                for (int pos : palabraPos) {
                    salidaPos += pos + ".";
                }
                System.out.println("\t\t\t" + linea + "\t\t" + salidaPos);

            }

        }

    }


}
