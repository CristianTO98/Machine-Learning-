package org.uma.mbd.mdIndicePalabrasv1.indices;

import java.util.*;

public class IndiceLineas extends Indice {

    private Map<String, Set<Integer>> indice;

    public IndiceLineas() {
        super();
        indice = new TreeMap<>();
    }

    @Override
    public void agregarLinea(String texto) {
        super.agregarLinea(texto);
        indice.clear();


    }

    @Override
    public void resolver(String delimitadores, Collection<String> noSignificativas) {

        // Introducimos en un conjunto las palabras no significativas en minúsculas.
        Set<String> conjNoSignif = super.crearSetNoSignMinuscula(noSignificativas);
        //Analizamos el texto para formar el indice

        for (int i = 0; i < texto.size(); i++) {
            try (Scanner scLineaText = new Scanner(texto.get(i))) {
                scLineaText.useDelimiter(delimitadores);
                while (scLineaText.hasNext()) {
                    String palabra = scLineaText.next().toLowerCase();
                    if (!conjNoSignif.contains(palabra)) {
                        //Buscamos palabra en el diccionario
                        Set<Integer> valor = indice.computeIfAbsent(palabra, key -> new TreeSet<>());
                        if (!valor.contains(i + 1))
                            valor.add(i + 1);
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println(e.getMessage());
            } catch (NoSuchElementException e) {
                System.out.println(e.getMessage());
            }

        }


    }

    @Override
    public void presentarIndiceConsola() {

        for (Map.Entry<String, Set<Integer>> entrada : indice.entrySet()) {
            String clave = entrada.getKey();
            Set<Integer> valor = entrada.getValue();
            String salidaValor = "";
            for (int v : valor) {
                salidaValor += v + ".";
            }
            System.out.println(clave + "\t\t" + salidaValor);

        }

    }


}
