package org.uma.mbd.mdAlturasV2;


import org.uma.mbd.mdAlturasV2.alturas.MenoresQue;
import org.uma.mbd.mdAlturasV2.alturas.Mundo;
import org.uma.mbd.mdAlturasV2.alturas.Pais;

import java.io.IOException;
import java.util.*;

public class MainMundo {
    public static void main(String args[]) throws IOException {
        Mundo paises = new Mundo();
        paises.leePaises("recursos/mdAlturas/alturas.txt");

        List<Pais> listaPaises = paises.selecciona(new MenoresQue(1.8));


        //Apartado A
        System.out.println("Apartado A: \n");
        Comparator<Pais> cAlt = Comparator.comparingDouble(Pais::altura);
        SortedSet<Pais> porAltura = new TreeSet<>(cAlt);
        porAltura.addAll(listaPaises);
        for (Pais p : porAltura) {
            System.out.println(p);
        }
        System.out.println();


        //Apartado B
        System.out.println("Aparatado B: \n");

        Comparator<Pais> cAlfb = Comparator.comparing(Pais::nombre);
        SortedSet<Pais> porAlfabeto = new TreeSet<>(cAlfb);
        porAlfabeto.addAll(listaPaises);
        for (Pais p : porAlfabeto) {
            System.out.println(p);
        }
        System.out.println();

        //Apartado C
        System.out.println("Apartado C: \n");

        Comparator<Pais> cContinente = Comparator.comparing(Pais::continente);
        SortedSet<Pais> porContAlfb = new TreeSet<>(cContinente.thenComparing(cAlfb));
        porContAlfb.addAll(listaPaises);
        for (Pais p : porContAlfb) {
            System.out.println(p);
        }
        System.out.println();

        // Apartado D

        System.out.println("Apartado D: \n");

        SortedSet<Pais> porContAlfbRev = new TreeSet<>(cContinente.thenComparing(cAlfb.reversed()));
        porContAlfbRev.addAll(listaPaises);
        for (Pais p : porContAlfbRev) {
            System.out.println(p);
        }
        System.out.println();

        //Apartado e

        System.out.println("Apartado e: \n");

        SortedSet<Pais> porOrdenNatural = new TreeSet<>();
        porOrdenNatural.addAll(listaPaises);
        for (Pais p : porOrdenNatural) {
            System.out.println(p);
        }
        System.out.println();

        //Apartado f
        System.out.println("Apartado f: \n");

        SortedSet<Pais> porContinenteOrdenNat = new TreeSet<>(cContinente.thenComparing(Comparator.naturalOrder()));
        porContinenteOrdenNat.addAll(listaPaises);
        for (Pais p : porContinenteOrdenNat) {
            System.out.println(p);
        }
        System.out.println();


    }


}
