package org.uma.mbd.mdAlturasV2.alturas;

@FunctionalInterface
public interface Seleccion {

    boolean test(Pais pais);

}
