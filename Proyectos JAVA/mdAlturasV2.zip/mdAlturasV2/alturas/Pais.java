package org.uma.mbd.mdAlturasV2.alturas;

public record Pais(String nombre, String continente, double altura) implements Comparable<Pais> {


    @Override
    public boolean equals(Object o) {
        return (o instanceof Pais p) && nombre.equalsIgnoreCase(p.nombre()) && continente.equalsIgnoreCase(p.continente)
                && altura == p.altura;
    }

    @Override
    public int hashCode() {
        return nombre.hashCode() + continente.hashCode() + Double.hashCode(altura);
    }

    @Override
    public int compareTo(Pais p) {

        int resultado;
        resultado = Double.compare(altura, p.altura);
        if (resultado == 0)
            resultado = nombre.compareToIgnoreCase(p.nombre);

        return resultado;

    }


}
