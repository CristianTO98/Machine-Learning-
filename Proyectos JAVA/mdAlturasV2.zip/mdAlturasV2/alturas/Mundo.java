package org.uma.mbd.mdAlturasV2.alturas;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class Mundo {

    private List<Pais> paises;

    public Mundo() {
        paises = new ArrayList<>();
    }

    public List<Pais> getPaises() {
        return paises;
    }

    public void leePaises(String file) throws IOException {

        List<String> fichero = Files.readAllLines(Path.of(file));
        for (String linea : fichero) {
            try (Scanner scLinea = new Scanner(linea)) {
                scLinea.useDelimiter(",");
                String nombre = scLinea.next();
                String continente = scLinea.next();
                double altura = Double.parseDouble(scLinea.next());
                paises.add(new Pais(nombre, continente, altura));
            } catch (InputMismatchException e) {
                throw new InputMismatchException("Error de fichero. Dato erróneo");
            } catch (NoSuchElementException e) {
                throw new NoSuchElementException("Error de fichero. Faltan datos");
            }
        }

    }


    public List<Pais> selecciona(Seleccion sel) {

        List<Pais> paisesSel = new ArrayList<>();

        for (Pais p : paises) {
            if (sel.test(p))
                paisesSel.add(p);
        }

        return paisesSel;


    }


}



