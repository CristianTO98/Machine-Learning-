package org.uma.mbd.mdTren.tren;

public class Vagon {

    private int capacidad, carga;

    public Vagon(int cap) {

        capacidad = cap;
        carga = 0;

    }

    public int carga(int ton) {

        int disponible = capacidad - carga;

        if (ton >= (disponible)) {
            carga += disponible;
            ton = ton - disponible;
        } else {
            carga += ton;
            ton = 0;
        }

        return ton;


    }

    public int descarga(int ton) {

        if (ton >= carga) {
            ton = ton - carga;
            carga = 0;

        } else {

            carga = carga - ton;
            ton = 0;

        }

        return ton;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public int getCarga() {
        return carga;
    }

    @Override
    public String toString() {

        return "V(" + carga + ", " + capacidad + ")";

    }


}

