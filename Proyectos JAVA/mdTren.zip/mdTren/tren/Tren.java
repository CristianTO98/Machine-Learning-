package org.uma.mbd.mdTren.tren;

import java.util.ArrayList;
import java.util.List;

public class Tren {

    private int numVagones, capacidad;
    private List<Vagon> vagones;

    public Tren(int numV, int cap) {
        if (numV <= 0 || cap <= 0)
            throw new RuntimeException("Número de vagones o capacidad no puede ser menor o igual a 0");
        numVagones = numV;
        capacidad = cap;
        vagones = new ArrayList<>();
        //Rellenamos la Lista
        for (int i = 0; i < numVagones; i++) {
            anadirVagon(i);
        }

    }

    public void carga(int ton) {

        if (ton <= 0)
            throw new RuntimeException("No se puede cargar 0 o menos toneladas");

        int i = 0;
        while (ton > 0) {
            if (i < numVagones) {
                ton = vagones.get(i).carga(ton);
                i++;
            }
            //Si cargamos todos los vagones y no son suficientes
            else {
                anadirVagon(i);
                ton = vagones.get(i).carga(ton);
                i++;
                numVagones++;
            }
        }
    }

    private void anadirVagon(int i) {
        Vagon v = new Vagon(capacidad);
        vagones.add(i, v);
    }

    public void gasta(int ton) {

        if (ton <= 0)
            throw new RuntimeException("No se puede descargar 0 o menos toneladas");

        int i = 0;
        while (ton > 0) {
            if (i < numVagones) {
                ton = vagones.get(i).descarga(ton);
                i++;
            } else {
                throw new IllegalArgumentException("No hay suficiente carga");
            }
        }
    }

    public void optimiza() {
        for (int i = 0; i < numVagones; i++) {
            if (vagones.get(i).getCarga() == 0)
                vagones.remove(i);
            numVagones--;
        }
    }


    @Override
    public String toString() {
        String salida = "Tren[";
        for (int i = 0; i < numVagones; i++) {
            salida += vagones.get(i);
            if (i < numVagones - 1)
                salida += ", ";
        }
        salida += "]";
        return salida;
    }


}
