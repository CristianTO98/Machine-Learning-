package org.uma.mbd.mdGenetico.genetico;



public class AGUnPunto extends AlgoritmoGenetico {


    public AGUnPunto(int tamPob, int longIndv, int gen, double probMut, Problema p) {
        super(tamPob, longIndv, gen, probMut, p);
    }

    @Override
    protected Cromosoma recombinar(Cromosoma c1, Cromosoma c2) {


        int z = Cromosoma.gna.nextInt(0, c1.getLongitud());

        Cromosoma nuevoCrom = new Cromosoma(c1.getLongitud(), true);

        for (int i = 0; i < nuevoCrom.datos.length; i++) {
            nuevoCrom.datos[i] = z >= i ? c1.datos[i] : c2.datos[i];
        }

        return nuevoCrom;
    }
}