package org.uma.mbd.mdGenetico.genetico;

public class CeroMax implements Problema {

    @Override
    public double evalua(Cromosoma c) {
        double fitness = 0;
        for (int i = 0; i < c.longitud; i++) {
            if (c.datos[i] == 0)
                fitness++;
        }
        return fitness;
    }
}
