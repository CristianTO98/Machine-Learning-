package org.uma.mbd.mdGenetico.genetico;

public class OneMax implements Problema {

    @Override
    public double evalua(Cromosoma c) {
        double fitness = 0;
        for (int i = 0; i < c.longitud; i++) {
            if (c.datos[i] == 1)
                fitness++;
        }
        return fitness;
    }
}
