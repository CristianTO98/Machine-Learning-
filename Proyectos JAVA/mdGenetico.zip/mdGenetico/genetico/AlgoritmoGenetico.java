package org.uma.mbd.mdGenetico.genetico;



public abstract class AlgoritmoGenetico {

    private Poblacion poblacion;
    private Problema problema;
    private int pasos;
    private double probMutacion;


    public AlgoritmoGenetico(int tamPob, int longIndv, int gen, double probMut, Problema p) {
        problema = p;
        pasos = gen;
        probMutacion = probMut;
        poblacion = new Poblacion(tamPob, longIndv, p);

    }

    public Individuo ejecuta() {

        for (int i = 1; i <= pasos; i++) {
            //Escogemos individuos aleatorios
            int n1, n2;
            n1 = Cromosoma.gna.nextInt(0, poblacion.getNumIndividuos());
            do {
                n2 = Cromosoma.gna.nextInt(0, poblacion.getNumIndividuos());

            } while (n1 == n2);
            Individuo individuo1 = poblacion.getIndividuo(n1);
            Individuo individuo2 = poblacion.getIndividuo(n2);
            // Recombinamos sus cromosomas
            Cromosoma cromRecomb = recombinar(individuo1.getCromosoma(), individuo2.getCromosoma());
            // Mutamos el cromosoma resultante con la prob indicada
            cromRecomb.mutar(probMutacion);
            // Crear y insertar si se da el caso, al nuevo individuo
            Individuo nuevoIndiv = new Individuo(cromRecomb, problema);
            poblacion.reemplaza(nuevoIndiv);
        }
        // Devolver el mejor inidividuo de la población
        return poblacion.mejorIndividuo();


    }

    protected abstract Cromosoma recombinar(Cromosoma c1, Cromosoma c2);


}
