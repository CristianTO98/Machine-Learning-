package org.uma.mbd.mdGenetico.genetico;



public class AGUniforme extends AlgoritmoGenetico {


    public AGUniforme(int tamPob, int longIndv, int gen, double probMut, Problema p) {
        super(tamPob, longIndv, gen, probMut, p);
    }


    @Override
    protected Cromosoma recombinar(Cromosoma c1, Cromosoma c2) {


        Cromosoma nuevoCrom = new Cromosoma(c1.getLongitud(), true);

        for (int i = 0; i < nuevoCrom.datos.length; i++) {

            int cromAlea = Cromosoma.gna.nextInt(0, 2);
            nuevoCrom.datos[i] = cromAlea == 0 ? c1.datos[i] : c2.datos[i];
        }

        return nuevoCrom;

    }
}
