package org.uma.mbd.mdGenetico.genetico;

import java.util.Arrays;
import java.util.Random;

public class Cromosoma {

    protected int[] datos;
    protected static Random gna = new Random();
    protected static int GEN_POR_DEFECTO = 0;
    protected int longitud;

    public Cromosoma(int longitud, boolean alea) {
        if (longitud <= 0)
            throw new RuntimeException("Longitud debe de ser mayor a 0.");
        this.longitud = longitud;
        datos = new int[longitud];
        for (int i = 0; i < datos.length; i++) {
            datos[i] = alea ? gna.nextInt(2) : GEN_POR_DEFECTO;
        }

    }


    public int getGen(int pos) {
        if (pos < 0 || pos >= datos.length)
            throw new RuntimeException("El índice está fuera del rango de valores válidos");
        return datos[pos];
    }

    public void setGen(int pos, int valor) {
        if (pos < 0 || pos >= datos.length || valor < 0 || valor > 1)
            throw new RuntimeException("El valor i está fuera del rango de valores válidos o el valor val no es un valor válido");
        datos[pos] = valor;
    }

    public int getLongitud() {
        return longitud;
    }

    public void mutar(double prob) {
        if (prob < 0 || prob > 1)
            throw new RuntimeException("La probabilidad debe de encontrarse entre 0 y 1.");
        for (int i = 0; i < datos.length; i++) {
            if (prob > gna.nextDouble(0, 1))
                datos[i] = datos[i] == 0 ? 1 : 0;
        }

    }


    public Cromosoma copia() {

        Cromosoma copia = new Cromosoma(datos.length, false);
        copia.datos = Arrays.copyOf(datos, datos.length);
        return copia;
    }

    @Override
    public String toString() {

        String salida = "C(";
        for (int i = 0; i < datos.length; i++) {
            salida += datos[i];
            if (i < datos.length - 1)
                salida += ", ";

        }
        salida += ")";
        return salida;

    }

}
