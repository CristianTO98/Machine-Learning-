package org.uma.mbd.mdGenetico.genetico;

public class Poblacion {

    private int numIndividuos;
    private Individuo[] individuos;

    public Poblacion(int numIndividuos, int longitud, Problema p) {
        if (numIndividuos <= 0 || longitud <= 0)
            throw new RuntimeException("Tanto la longitud como el número de individuos debe ser mayor a 0");
        this.numIndividuos = numIndividuos;
        individuos = new Individuo[numIndividuos];
        for (int i = 0; i < numIndividuos; i++) {
            individuos[i] = new Individuo(longitud, p);
        }

    }

    public int getNumIndividuos() {
        return numIndividuos;
    }

    public Individuo getIndividuo(int ind) {
        if (ind < 0 || ind >= individuos.length)
            throw new RuntimeException("El índice está fuera de los valores de rango válidos");
        return individuos[ind];
    }

    public Individuo mejorIndividuo() {
        Individuo mejor = individuos[0];
        for (int i = 1; i < numIndividuos; i++) {
            if (mejor.getFitness() < individuos[i].getFitness())
                mejor = individuos[i];
        }
        return mejor;
    }

    public void reemplaza(Individuo individuo) {
        Individuo peor = individuos[0];
        int pos = 0;
        for (int i = 1; i < numIndividuos; i++) {
            if (peor.getFitness() > individuos[i].getFitness()) {
                peor = individuos[i];
                pos = i;
            }
        }
        if (individuo.getFitness() > peor.getFitness())
            individuos[pos] = individuo;

    }


}
