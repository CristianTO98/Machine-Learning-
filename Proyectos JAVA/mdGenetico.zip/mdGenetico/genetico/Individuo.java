package org.uma.mbd.mdGenetico.genetico;

public class Individuo {

    private Cromosoma cromosoma;
    private double fitness;

    public Individuo(int longitud, Problema p) {
        cromosoma = new Cromosoma(longitud, true);
        fitness = p.evalua(cromosoma);

    }

    public Individuo(Cromosoma c, Problema p) {
        cromosoma = c.copia();
        fitness = p.evalua(cromosoma);

    }

    public Cromosoma getCromosoma() {
        return cromosoma.copia();
    }

    public double getFitness() {
        return fitness;
    }

    @Override
    public String toString() {
        return "Individuo(" + cromosoma.toString() + ", " + getFitness() + ")";
    }


}