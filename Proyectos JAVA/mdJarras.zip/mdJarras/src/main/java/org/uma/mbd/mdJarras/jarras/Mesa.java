package org.uma.mbd.mdJarras.jarras;

/*3. Crear la clase Mesa que dispondrá de dos jarras A y B (jarraA y jarraB). Se pide:

a. Un constructor que cree una mesa con dos jarras de tamaño inicial dados. Tendrá dos
argumentos que serán las capacidades iniciales de las jarras A y B.
b. Métodos void llenaA() y void llenaB() para llenar las jarras A y B
respectivamente y métodos void vaciaA() y void vaciaB() para vaciar las
jarras A y B.
c. Métodos void vuelcaASobreB() y void vuelcaBsobreA() que vuelque la
jarra A sobre la jarra B o la B sobre la A.
d. Métodos int getContenidoA(), int getContenidoB(), int
getCapacidadA() e int getCapacidadB() de devuelvan los contenidos y
capacidades de las jarra A y B.
e. Método int getContenido() que devuelva el contenido total de las dos jarras A
y B.
f. Método String toString() que muestre las dos jarras que hay en la mesa.*/

public class Mesa {
    //Atributos
    private Jarra jarraA;
    private Jarra jarraB;

    // Método constructor
    public Mesa(int a, int b){
     jarraA = new Jarra(a);
     jarraB = new Jarra(b);
    }

    // Métodos

    public void llenaA(){
        jarraA.llena();
    }

    public void llenaB(){
        jarraB.llena();
    }

    public void vaciaA(){
        jarraA.vacia();
    }

    public void vaciaB(){
        jarraB.vacia();
    }

    public void vuelcaASobreB(){
        jarraB.llenaDesde(jarraA);
    }

    public void vuelcaBSobreA(){
        jarraA.llenaDesde(jarraB);
    }

    public int getContenidoA(){

        return jarraA.getContenido();
    }

    public int getContenidoB(){

        return jarraB.getContenido();
    }

    public int getCapacidadA(){
        return jarraA.getCapacidad();
    }

    public int getCapacidadB(){
        return jarraB.getCapacidad();
    }

    public int getContenido(){

        return (getContenidoA()+getContenidoB());
    }
    @Override
    public String toString(){

        return "Jarra A (Capacidad: "+ jarraA.getCapacidad()+", Contenido: "+jarraA.getContenido()+")"+"\n"+
                "Jarra B (Capacidad: "+ jarraB.getCapacidad()+", Contenido: "+jarraB.getContenido()+")";
    }







}
