package org.uma.mbd.mdJarras;
import org.uma.mbd.mdJarras.jarras.Jarra;

/*2. Para probar nuestra nueva clase vamos a construir una aplicación que cree dos jarras, una con
capacidad para 5 litros y otra para 7. Una vez creadas hemos de realizar las operaciones
necesarias para dejar en una de las jarras exactamente un litro de agua.*/


public class Punto2 {

    public static void main(String[] args) {

        //Creamos Jarras
        Jarra j1 = new Jarra(5);
        Jarra j2 = new Jarra(7);

        // Tenemos que dejar contenido = 1 al menos en 1 de las jarras
        j1.llena();
        j2.llenaDesde(j1);
        j1.llena();
        j2.llenaDesde(j1);
        j2.vacia();
        j2.llenaDesde(j1);
        j1.llena();
        j2.llenaDesde(j1);

        System.out.println("j1 = "+ j1.toString());
        System.out.println("j2 = "+ j2.toString());




    }


}
