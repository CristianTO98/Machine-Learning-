package org.uma.mbd.mdJarras.jarras;

/*1. Hay que construir la clase Jarra con los métodos necesarios para realizar las operaciones
que acabamos de describir. Además de dichas operaciones necesitamos métodos para
consultar tanto la cantidad de agua que tiene una jarra como su capacidad. Definir el método
public String toString() que devuelva un String que represente los datos
de la jarra.*/


public class Jarra {

// Atributos

    private final int capacidad;
    private int contenido;

// Métodos

    public Jarra(int cap){ //Constructor

        capacidad = cap;
        contenido = 0;

    }

    public void llena(){
        contenido = capacidad;
    }

    public void vacia(){
        contenido = 0;
    }

    public void llenaDesde(Jarra j2) {
        int cabej1;
        cabej1 = capacidad - contenido;
        if (j2.contenido > cabej1) {
            contenido += cabej1;
            j2.contenido -= cabej1;
        } else {
            contenido += j2.contenido;
            j2.contenido = 0;

        }
    }
    @Override
    public String toString(){

            return "j(Capacidad: "+ capacidad+ ", Contenido: "+contenido+")";
        }


    public int getCapacidad() {
        return capacidad;
    }

    public int getContenido() {
        return contenido;

    }
}
