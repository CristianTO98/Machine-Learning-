package org.uma.mbd.mdJarras;
import org.uma.mbd.mdJarras.jarras.*;

/*4. Crear una aplicación que cree una mesa con valores iniciales de las jarras de 7 y 5 litros y
realice las operaciones necesarias para que en una de las jarras quede 1 litro.*/

public class Punto4 {

    public static void main(String[] args) {

    //Creamos objeto mesa
    Mesa mesa = new Mesa(7,5);

    //Operamos para dejar 1 l en una de las jarras
    mesa.llenaB();
    mesa.vuelcaBSobreA();
    mesa.llenaB();
    mesa.vuelcaBSobreA();
    mesa.vaciaA();
    mesa.vuelcaBSobreA();
    mesa.llenaB();
    mesa.vuelcaBSobreA();

    //Imprimimos nuestro objeto mesa
        System.out.println(mesa.toString());




    }

}
