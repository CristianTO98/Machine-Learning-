package org.uma.mbd.mdPartidos.partidos;

import java.util.List;
import java.util.Map;

@FunctionalInterface
public interface CriterioSeleccion {
    Map<Partido, Integer> ejecuta(List<Partido> partidos, int numEsc);
}
