package org.uma.mbd.mdPartidos.partidos;

import java.io.IOException;
import java.io.PrintWriter;

public class EleccionesManager {

    private String fEntrada;
    private String fSalida;
    private boolean consola;
    private String[] datos;
    private CriterioSeleccion cs;
    private int numEsc;
    private Elecciones elecciones;

    public EleccionesManager(Elecciones elecciones) {

        this.elecciones = elecciones;

    }

    public EleccionesManager setDatos(String[] datos) {

        this.datos = datos;
        return this;

    }

    public EleccionesManager setCriterioSeleccion(CriterioSeleccion cs) {
        this.cs = cs;
        return this;
    }

    public EleccionesManager setNumEsc(int numEsc) {
        this.numEsc = numEsc;
        return this;

    }

    public EleccionesManager setEntrada(String fEntrada) {
        this.fEntrada = fEntrada;
        return this;
    }

    public EleccionesManager setSalida(String fSalida) {
        this.fSalida = fSalida;
        return this;
    }

    public EleccionesManager setConsola(boolean consola) {
        this.consola = consola;
        return this;
    }

    private void verify() {
        // Verificamos entrada de datos
        if (datos != null && fEntrada != null)
            throw new EleccionesException("Solo puede haber una única fuente de datos");
        else if (datos == null && fEntrada == null)
            throw new EleccionesException("Debe de haber una fuente de entrada de datos");
        // Verificamos criterio
        if (cs == null)
            throw new EleccionesException("No hay criterio de selección");
        // Verificamos escaños
        if (numEsc == 0)
            throw new EleccionesException("No hay escaños para repartir");
        else if (numEsc < 0)
            throw new EleccionesException("El número introducido no puede ser negativo");
        // Verificamos salida
        if (fSalida == null && !consola)
            throw new EleccionesException("Debe de haber al menos una salida para los datos generados");

    }

    public void build() throws IOException {

        verify();

        if (fEntrada == null)
            elecciones.leeDatos(datos);
        else
            elecciones.leeDatos(fEntrada);

        if (consola) {

            elecciones.presentaResultados(new PrintWriter(System.out, true), elecciones.generaResultados(cs, numEsc));
        }

        if (fSalida != null) {
            elecciones.presentaResultados(fSalida, elecciones.generaResultados(cs, numEsc));
        }

    }


}
