package org.uma.mbd.mdPartidos.partidos;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Proporcional implements CriterioSeleccion {


    @Override
    public Map<Partido, Integer> ejecuta(List<Partido> partidos, int numEsc) {

        return Token.generaResultados(Token.seleccionaTokens(creaTokens(partidos, numEsc), numEsc));


    }

    private Set<Token> creaTokens(List<Partido> partidos, int numEsc) {

        double vpe = partidos.stream()
                .mapToDouble(p -> p.getVotos() / numEsc)
                .sum();
        Set<Token> tokens = new TreeSet<>();
        for (Partido p : partidos) {
            for (int i = 0; i < numEsc; i++) {

                tokens.add(new Token(p, (p.getVotos() - vpe * i)));
            }
        }
        return tokens;

    }
}
