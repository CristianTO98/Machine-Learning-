package org.uma.mbd.mdPartidos.partidos;

import java.util.*;
import java.util.stream.Collectors;

public class Token implements Comparable<Token> {

    public Partido partido;
    public double ratio;

    public Token(Partido partido, Double ratio) {

        this.partido = partido;
        this.ratio = ratio;

    }

    public Partido getPartido() {
        return partido;
    }

    public double getRatio() {
        return ratio;
    }


    @Override
    public int compareTo(Token t) {
        int resultado = -Double.compare(ratio, t.ratio);
        if (resultado == 0)
            resultado = partido.getNombre().compareToIgnoreCase(t.partido.getNombre());
        return resultado;

    }

    public static Set<Token> seleccionaTokens(Set<Token> tks, int numEsc) {

        return tks.stream().limit(numEsc).collect(Collectors.toSet());

    }

    public static Map<Partido, Integer> generaResultados(Set<Token> tks) {

        return tks.stream()
                .collect(Collectors.groupingBy(Token::getPartido, Collectors.summingInt(p -> 1)));


    }


}