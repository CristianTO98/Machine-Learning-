package org.uma.mbd.mdPartidos.partidos;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DHont extends DHontSimple {

    private double minPor;

    public DHont(double mp) {
        if (mp < 0 || mp >= 15)
            throw new EleccionesException("Porcentaje mínimo de votos fuera de rango");
        minPor = mp;
    }

    @Override
    public Map<Partido, Integer> ejecuta(List<Partido> partidos, int numEsc) {

        return super.ejecuta(filtraPartidos(partidos), numEsc);

    }

    private List<Partido> filtraPartidos(List<Partido> partidos) {

        long sumVotos = partidos.stream()
                .mapToInt(Partido::getVotos)
                .sum();
        return partidos.stream()
                .filter(p -> ((p.getVotos() * 100) / sumVotos) >= minPor)
                .collect(Collectors.toList());
    }

}
