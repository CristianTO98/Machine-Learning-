package org.uma.mbd.mdPartidos.partidos;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Elecciones {

    private List<Partido> partidos;

    static private Partido stringToPartido(String dato) {
        try (Scanner scDato = new Scanner(dato)) {
            scDato.useDelimiter("[,]+");
            String nombre = scDato.next();
            int votos = scDato.nextInt();
            return new Partido(nombre, votos);
        } catch (InputMismatchException e) {
            throw new EleccionesException("El token recuperado no coincide con el patrón para el tipo esperado," +
                                         " o que el token está fuera del rango para el tipo esperado.");
        } catch (NoSuchElementException e) {
            throw new EleccionesException("Falta elemento en la enumeración. Imposible extraer dato");
        } catch (RuntimeException e){
            throw new EleccionesException(e.getMessage());
        }
    }

    public void leeDatos(String[] datos) {
        if (datos == null)
            throw new EleccionesException("El string de datos está vacío");
        partidos = Arrays.stream(datos)
                .map(Elecciones::stringToPartido)
                .collect(Collectors.toList());

    }


    public void leeDatos(String nombreFichero) throws IOException {

        try (Stream<String> stream = Files.lines(Path.of(nombreFichero))) {
            partidos = stream
                    .map(Elecciones::stringToPartido)
                    .collect(Collectors.toList());
        }

    }

    public Map<Partido, Integer> generaResultados(CriterioSeleccion cs, int numEsc) {

        return cs.ejecuta(partidos, numEsc);

    }

    public void presentaResultados(String nombreFichero, Map<Partido, Integer> map) throws FileNotFoundException {

        try (PrintWriter pw = new PrintWriter(nombreFichero)) {
            presentaResultados(pw, map);
        }


    }


    public void presentaResultados(PrintWriter pw, Map<Partido, Integer> map) {
        // Creamos una copia de la lista partidos y la ordenamos por votos
        // Esto se realiza, por si el fichero de entrada proporciona los partidos desordenados
        List<Partido> partidosCopia = new ArrayList<>(partidos);
        partidosCopia.stream()
                .sorted(Comparator.comparingInt(Partido::getVotos).reversed())
                .map(p -> {
                    int escanos = map.getOrDefault(p, 0);
                    String representacion = escanos == 0 ? "Sin representacion" : String.valueOf(escanos);
                    return p + ", " + representacion;
                })
                .forEach(pw::println);


    }

}